#coding=utf-8
import pygame
from pygame.sprite import Sprite

class Bullet(Sprite):

    def __init__(self, ai_settings, screen, body):
        #在主题所处的位置创建弹幕对象
        super(Bullet, self).__init__()
        self.screen = screen

        #在(0，0)处创建矩形，在设置正确位置
        self.image = pygame.image.load('images/修车.bmp')
        self.rect = self.image.get_rect()
        #self.screen_rect = screen.get_rect()!!
        self.rect.centerx = body.rect.centerx
        self.rect.bottom = body.rect.bottom

        #存储用小数表示的弹幕位置
        self.y = float(self.rect.y)

        self.speed_factor = ai_settings.bullet_speed_factor

    def update(self):
        self.y -= self.speed_factor
        self.rect.y = self.y

    def draw_bullet(self):
        self.screen.blit(self.image, self.rect)
