#coding=utf-8
class Settings():

    def __init__(self):
        #初始化
        #屏幕设置
        self.screen_wigth = 1200
        self.screen_height = 800
        self.bg_color = (255,255,255)


        #图的设置
        self.body_speed_factor = 1.5

        #弹幕设置
        self.bullet_speed_factor = 0.1
        # self.bullet_width = 3
        # self.bullet_height = 15
        # self.bullet_color = 60, 60, 60
