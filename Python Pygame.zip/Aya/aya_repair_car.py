#coding=utf-8
import pygame
from pygame.sprite import Group
from settings import Settings
from body import Body
import game_functions as gf

def run_game():
    #初始化游戏并创建屏幕对象
    pygame.init()
    icon = pygame.image.load('images/Aya_icon.png')
    pygame.display.set_icon(icon)
    ai_settings = Settings()
    screen = pygame.display.set_mode(
        (ai_settings.screen_wigth, ai_settings.screen_height))
    pygame.display.set_caption("aya酱修车しゅわりん☆どり～みん")

    #创建主体
    body = Body(ai_settings, screen)
    #创建用于存储弹幕编组
    bullets = Group()

    #游戏主循环
    while True:
        gf.check_events(ai_settings, screen, body, bullets)
        body.update()
        bullets.update()
        gf.update_bullets(bullets)
        gf.update_screen(ai_settings, screen, body, bullets)

run_game()