%%%%%%%%%%%%%%%%%%%%%%%%%%%%%录音
fs=8000;
recorder = audiorecorder(fs,8,1);%创建用于录制音频的对象
%record(recorder,2)%指定录制秒数为2s
fprintf('开始录音');
recordblocking(recorder, 2);  % 录音2秒
fprintf('结束录音');
y = getaudiodata(recorder);%将录制的对象存储在数值数组中
play(recorder)%播放音频
z=fft(y);%作FFT变换,z是频率信号
figure(1)
subplot(4,1,1)
plot(y);title('原始语音信号的时域波形');
subplot(4,1,2)
plot(z);title('原始语音信号的频域波形');
subplot(4,1,3)
plot(abs(z));title('原始语音信号的频谱(幅频响应）');%幅频响应特性
subplot(4,1,4)
plot(angle(z));title('原始语音信号的频谱（相频响应）');%相频响应特性

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%低通滤波器设计及频谱分析
wp=0.4*pi; %数字通带频率
ws=0.6*pi; %数字阻带频率
Rp=0.5; %通带波动（dB）
As=50; %阻带波动（dB）
Fs=1000; %置 Fs=1000
OmegaP=wp*Fs; %原型通带频率
OmegaS=ws*Fs; %原型阻带频率
%模拟巴特沃斯原型滤波器计算
[N,OmegaC]=buttord(OmegaP,OmegaS,Rp,As,'s'); 
[z0,p0,k0]=buttap(N); 
%归一化巴特沃斯原型设计函数
p=p0*OmegaC;z1=z0*OmegaC;
%将零点极点乘以 OmegaC， 得到非归一化零极点
k=k0*OmegaC^N; %将 k（）乘以 Omegac^N，得到非归一化 k
ba=k*real(poly(z1)); %用零点计算分子系数向量
aa=real(poly(p)); %用极点计算分母系数向量
[bd,ad]=impinvar(ba,aa,Fs); %调用冲激响应不变法函数
[H,w]=freqz(bd,ad,1000,'whole'); %计算数字系统频率响应
mag=abs(H); %求其幅频特性
pha=angle(H); %求其相频特性
figure(2)
subplot(2,1,1);plot(w/pi,mag); title('幅度响应');
xlabel('单位π');ylabel('幅值');axis([0,1,0,1.1]);
subplot(2,1,2);plot(w/pi,pha/pi); title('相位响应');
xlabel('单位π');ylabel('相位(单位π)');axis([0,1,-1,1]);
y1=filter(bd,ad,y);
z1=filter(bd,ad,z);
figure(3);
subplot(4,1,1)
plot(y1);title('低通滤波语音信号的时域波形');
subplot(4,1,2)
plot(z1);title('低通滤波语音信号的频域波形');
subplot(4,1,3)
plot(abs(z1));title('低通滤波语音信号的频谱(幅频响应）');%幅频响应特性
subplot(4,1,4)
plot(angle(z1));title('低通滤波语音信号的频谱（相频响应）');%相频响应特性

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%高通滤波器设计及频谱分析
wp=0.6*pi;%通带
ws=0.4*pi;%阻带
tr_width=wp-ws;%带宽
wc=(ws+wp)/2;
N=ceil(8*pi/tr_width)+1;%fir滤波器阶数
b=fir1(N-1,wc/pi, 'high');%设计fir高通滤波器
n=0:1:N-1;
figure(4)
subplot(3,1,1);stem(n,b);
xlabel('n');ylabel('h(n)');title('冲激响应');
[h,w]=freqz(b,1,1000);
mag=abs(h);  %求其幅频特性
pha=angle(h);  %求其相频特性
subplot(3,1,2);plot(w/pi,20*log10(mag)); title('幅度响应');
xlabel('单位π');ylabel('幅度 dB');axis([0,1,-70,10]);
subplot(3,1,3);plot(w/pi,pha/pi); title('相位响应');
xlabel('单位π');ylabel('相位(单位π)');axis([0,1,-1,1]);
y2=filter(b,1,y);
z2=filter(b,1,z);
figure(5)
subplot(4,1,1)
plot(y2);title('高通滤波语音信号的时域波形');
subplot(4,1,2)
plot(z2);title('高通滤波语音信号的频域波形');
subplot(4,1,3)
plot(abs(z2));title('高通滤波语音信号的频谱(幅频响应）');%幅频响应特性
subplot(4,1,4)
plot(angle(z2));title('高通滤波语音信号的频谱（相频响应）');%相频响应特性

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%信号频移及频移后信号的播放
x1=y(:,1);%取单列 
N=length(x1);%求信号长度 
n=0:N-1;%所有元素
t=(0:(N-1))/fs;%时间
f=0:fs/N:fs*(N-1)/N;%频率
w=2*f/fs;%归一化
%低频调制
x2=cos(n*0.1*pi);%低频时余弦信号
x22=x1.*x2';%低频调制信号
X2=fft(x2); 
X22=fft(x22);
figure(6);
subplot(4,1,1)
plot(x22);title('低频语音信号的时域波形');
subplot(4,1,2)
plot(fft(x22));title('低频语音信号的频域波形');
subplot(4,1,3)
plot(abs(fft(x22)));title('低频语音信号的频谱(幅频响应）');%幅频响应特性
subplot(4,1,4)
plot(angle(fft(x22)));title('低频语音信号的频谱（相频响应）');%相频响应特性
%高频调制
x3=cos(n*0.7*pi);%高频时余弦信号
x33=x1.*x3';%高频调制信号
X3=fft(x3); 
X33=fft(x33); 
figure(7);
subplot(4,1,1)
plot(x33);title('高频语音信号的时域波形');
subplot(4,1,2)
plot(fft(x33));title('高频语音信号的频域波形');
subplot(4,1,3)
plot(abs(fft(x33)));title('高频语音信号的频谱(幅频响应）');%幅频响应特性
subplot(4,1,4)
plot(angle(fft(x33)));title('高频语音信号的频谱（相频响应）');%相频响应特性
%播放调制信号
sound(x1,fs);%播放原音乐
pause(3);
sound(x22,fs);%低频调制播放
pause(3);
sound(x33,fs);%高频调制播放