Thank you for spending your time to check my Lab1 documents.
Here I will give you a brief list of my documents.

---------------------------------------------------------------------------

Lab_1 190897332.docx		Q5_sp10.jpg
Q1_DFT_Cosine.jpg		Q5_sp10_white.jpg
Q1_DFT_Delta.jpg		Q6_canyoukeep.jpg
Q1_DFT_Sine w=12.5.jpg		Q6_comeonyou.jpg
Q1_DFT_Sine w=25.jpg		Q6_maybenexttime.jpg
Q1_DFT_pulses.jpg		Q7_a.jpg
Q1_DFT_uniform.jpg		Q7_e.jpg
Q2_DFTvsFFT_Sine.jpg		Q7_i.jpg
Q2_DFTvsFFT_cos.jpg		Q7_o.jpg
Q2_DFTvsFFT_delta.jpg		Q7_u.jpg
Q2_DFTvsFFT_pulses.jpg		Q7a.jpg
Q2_DFTvsFFT_uniform.jpg		Q7c_spectrogram.jpg
Q2_complexity.jpg		Q7e_female_four.wav
Q2_loglogplot.jpg		Q7e_female_one.wav
Q3_n=1024.jpg			Q7e_female_three.wav
Q3_n=1024_log.jpg		Q7e_female_two.wav
Q3_n=256.jpg			Q7e_male_four.wav
Q3_n=256_log.jpg		Q7e_male_one.wav
Q3_n=54.jpg			Q7e_male_three.wav
Q3_n=54_log.jpg			Q7e_male_two.wav
Q3_t=10000.jpg			Q7f_female1.jpg
Q3_t=10000_log.jpg		Q7f_female2.jpg
Q3_t=110000.jpg			Q7f_female3.jpg
Q3_t=110000_log.jpg		Q7f_female4.jpg
Q3_t=60000.jpg			Q7f_male1.jpg
Q3_t=60000_log.jpg		Q7f_male2.jpg
Q3a_magnitude_frequency.jpg	Q7f_male3.jpg
Q3a_magnitude_time.jpg		Q7f_male4.jpg
Q4.1c_estimations.jpg		README.txt
Q4a_bwv827b.jpg			dft.m
Q4a_dbarrett2.jpg		loglog_plot.m
Q4a_piccolo.jpg			mySpectrogram.m
Q4a_vmatthew2.jpg		stem4.m
Q5_firework.jpg			wft.m
Q5_music.jpg

---------------------------------------------------------------------------

You can see all the plots with their titles from question1 to question7 are in JPEG format '.jpg'. 
You can see the program in the format '.m'.

And all the statements and answers for questions are in 'Lab_1 190897332.docx' word document. Please open it to check my answer. By the way, I draw all my answers in red font in order to look in a convenient way.

Thanks again for checking my Lab1 work. Sincerely hope you can have a good day!

Zhiyang Chen 
QMnumber:190897332