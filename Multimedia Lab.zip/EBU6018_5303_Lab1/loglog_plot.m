% Here we use 'td' and 'tf' to save the time tic,toc result 
% and finally get the loglog plot

td=[];
td1=[];
for (n=1:1000)
tic;
    
        dft(ones(1,n));
    
t=toc 
td1(n)=t;
end;

td2=[];
for (n=1:1000)
tic;
    
        dft(ones(1,n));
    
t=toc 
td2(n)=t;
end;

td3=[];
for (n=1:1000)
tic;
    
        dft(ones(1,n));
    
t=toc 
td3(n)=t;
end;

tf=[];
tf1=[];
for (n=1:1000)
tic;
     
        fft(ones(1,n));
    
t=toc 
tf1(n)=t;
end;

tf2=[];
for (n=1:1000)
tic;
     
        fft(ones(1,n));
    
t=toc 
tf2(n)=t;
end;

tf3=[];
for (n=1:1000)
tic;
     
        fft(ones(1,n));
    
t=toc 
tf3(n)=t;
end;

% calculate the average value of the time
td=(td1+td2+td3)/3;
tf=(tf1+tf2+tf3)/3;

% plot loglog_plot for dft and fft
n=[1:1000];
loglog(n,td);title('log-log plot');
hold on;
loglog(n,tf);
legend('dft','fft');