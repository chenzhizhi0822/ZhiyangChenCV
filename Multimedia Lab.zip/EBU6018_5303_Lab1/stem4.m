% Using this function to compare DFT and FFT
function stem4(s,s1)
s=dft(s);
s1=fft(s1);
subplot(4,2,1);stem(real(s));title('DFT-Real');
subplot(4,2,3);stem(imag(s));title('DFT-Imag');
subplot(4,2,5);stem(abs(s));title('DFT-Abs');
subplot(4,2,7);stem(angle(s));title('DFT-Angle');
subplot(4,2,2);stem(real(s1));title('FFT-Real');
subplot(4,2,4);stem(imag(s1));title('FFT-Imag');
subplot(4,2,6);stem(abs(s1));title('FFT-Abs');
subplot(4,2,8);stem(angle(s1));title('FFT-Angle');
end