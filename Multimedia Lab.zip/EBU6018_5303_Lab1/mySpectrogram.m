function mySpectrogram(x,fs,filename)

Nx = length(x);
nsc = floor(Nx/4.5);
noverlap = fs*0.01;
nfft = fs*0.02; % Determine the width of the 20ms window
w = 0.54 - 0.46 * cos(2*pi*[0:nfft-1]/(nfft-1));

% Using spectrogram function
figure('Position', [200 250 800 250]);
spectrogram(x,w,noverlap,nfft,fs,'yaxis');
title(filename); 