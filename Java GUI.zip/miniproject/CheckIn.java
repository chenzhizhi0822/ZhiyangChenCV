    /**
     * This class is the main class and is as the entry point to the Java application.
     * @author Zhiyang Chen
     * @version 1.0
     */
public class CheckIn extends MyFrame{

    /**
     * Main method only call the main frame and make it visiuable.
     * @param args The program does not use this parameter.
     * @author Zhiyang Chen
     */

    public static void main(String[] args) {
        MyFrame f = new MyFrame();
        f.setVisible(true);
    }
}
