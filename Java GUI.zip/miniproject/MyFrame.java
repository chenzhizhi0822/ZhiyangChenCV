import java.awt.*;
import javax.swing.*;        //导包
import javax.swing.border.Border;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList; 

    /**
     * This class is the main frame and contains all main components of the application.
     * @author Zhiyang Chen
     * @version 1.0
     */

public class MyFrame extends JFrame{

    JPanel p,p1,p2,p3,p4,p5,p6,p7,p8,p9;
    JTextArea firstNameJTextArea, surnameJTextArea, emailJTextArea, phoneJTextArea, bookingReferencecodeJTextArea;
    JLabel titleJLabel;
    JTextField emailJTextField, phoneJTextField, bookingReferencecodeJTextField;
    JComboBox<String> doBMonthJComboBox, doBYearJComboBox, programmeJComboBox, programmeYearJComboBox;
    JCheckBox checkBox1, checkBox2;
    JButton buttonNextstep, buttonClear, buttonExit;
    Border lineBorderBlack, lineBorderRed;

    /**
     * This method is the construcation method of the class MyFrame.
     * This method has no parameter.
     * @author Zhiyang Chen
     */

    public MyFrame(){
        super("Workshop Check in");//Using the construction method of the parent class.
        p = new JPanel();
        p.setLayout(new GridLayout(9,1,5,3));//Using GridLayout to arrange the GUI components

            p1 = new JPanel(new BorderLayout());
            titleJLabel = new JLabel("Please complete the information below: ", JLabel.CENTER);//Let the JLabel be in the center.
            Font fnt = new Font("Arial", Font.BOLD, 18);
            titleJLabel.setFont(fnt);//Set the font in the JLabel.
            p1.add(titleJLabel, BorderLayout.CENTER);//Let the JLabel be in the center.

            p2 = new JPanel();
            p2.setBorder(BorderFactory.createTitledBorder("Name"));//Use createTitledBorder() method to set the border of Jpanel.
            Color bgColor = new Color(255, 255, 255);
            lineBorderBlack = BorderFactory.createLineBorder(Color.black, 2);
                JPanel p2_1 = new JPanel();//This JPanel is the second level JPanel in JPanel p2
                p2_1.setBorder(BorderFactory.createTitledBorder(lineBorderBlack, "First Name"));//Composite border
                p2_1.setBackground(bgColor);//Set background color of the JPanel
                firstNameJTextArea = new JTextArea("John",1,10);
                p2_1.add(firstNameJTextArea);
                JPanel p2_2 = new JPanel();//This JPanel is the second level JPanel in JPanel p2
                p2_2.setBorder(BorderFactory.createTitledBorder(lineBorderBlack, "Surname"));
                p2_2.setBackground(bgColor);
                surnameJTextArea = new JTextArea("Doe",1,10);
                p2_2.add(surnameJTextArea);
            p2.add(p2_1);//Add the second level JPanel p2_1 into JPanel p2
            p2.add(p2_2);//Add the second level JPanel p2_2 into JPanel p2

            p3 = new JPanel();
            p3.setBorder(BorderFactory.createTitledBorder("Date of Birth"));//Use createTitledBorder() method to set the border of Jpanel.
                JPanel p3_1 = new JPanel();
                p3_1.setBorder(BorderFactory.createTitledBorder("Month"));
                doBMonthJComboBox = new JComboBox<String>();//Declare the variable types of JComboBox.
                doBMonthJComboBox.addItem(new String("---"));//Set Index 0.
                doBMonthJComboBox.addItem(new String("Jaurany"));
                doBMonthJComboBox.addItem(new String("Feburany"));
                doBMonthJComboBox.addItem(new String("March"));
                doBMonthJComboBox.addItem(new String("April"));
                doBMonthJComboBox.addItem(new String("May"));
                doBMonthJComboBox.addItem(new String("June"));
                doBMonthJComboBox.addItem(new String("July"));
                doBMonthJComboBox.addItem(new String("August"));
                doBMonthJComboBox.addItem(new String("Septumber"));
                doBMonthJComboBox.addItem(new String("Octomber"));
                doBMonthJComboBox.addItem(new String("November"));
                doBMonthJComboBox.addItem(new String("December"));
                p3_1.add(doBMonthJComboBox);
                JPanel p3_2 = new JPanel();
                p3_2.setBorder(BorderFactory.createTitledBorder("Year"));
                doBYearJComboBox = new JComboBox<String>();//Declare the variable types of JComboBox.
                doBYearJComboBox.addItem(new String("---"));//Set Index 0.
                doBYearJComboBox.addItem(new String("1998"));
                doBYearJComboBox.addItem(new String("1999"));
                doBYearJComboBox.addItem(new String("2000"));
                doBYearJComboBox.addItem(new String("2001"));
                doBYearJComboBox.addItem(new String("2002"));
                doBYearJComboBox.addItem(new String("2003"));
                doBYearJComboBox.addItem(new String("2004"));
                doBYearJComboBox.addItem(new String("2005"));
                p3_2.add(doBYearJComboBox);
            p3.add(p3_1);
            p3.add(p3_2);
                
            p4 = new JPanel();
            p4.setBorder(BorderFactory.createTitledBorder("Programme"));
                JPanel p4_1 = new JPanel();
                p4_1.setBorder(BorderFactory.createLoweredBevelBorder());
                programmeJComboBox = new JComboBox<String>();//Declare the variable types of JComboBox.
                programmeJComboBox.addItem(new String("---"));//Set Index 0.
                programmeJComboBox.addItem(new String("Telecommunication Engineering with management"));
                programmeJComboBox.addItem(new String("E-commerce and law"));
                programmeJComboBox.addItem(new String("Internet of things project"));
                p4_1.add(programmeJComboBox);
                JPanel p4_2 = new JPanel();
                p4_2.setBorder(BorderFactory.createLoweredBevelBorder());
                programmeYearJComboBox = new JComboBox<String>();//Declare the variable types of JComboBox.
                programmeYearJComboBox.addItem(new String("--"));//Set Index 0.
                programmeYearJComboBox.addItem(new String("1"));
                programmeYearJComboBox.addItem(new String("2"));
                programmeYearJComboBox.addItem(new String("3"));
                programmeYearJComboBox.addItem(new String("4"));
                p4_2.add(programmeYearJComboBox);
            p4.add(p4_1);
            p4.add(p4_2);

            p5 = new JPanel();
            p5.setBorder(BorderFactory.createTitledBorder("Email"));
            JPanel p5_1 =new JPanel(new GridLayout(1,1));
            p5_1.setBorder(BorderFactory.createLoweredBevelBorder());//Use createLoweredBevelBorder() method to get embedded border.
            p5_1.setBackground(bgColor);
            emailJTextArea = new JTextArea("john.doe@qmul.ac.uk",1 ,20);
            p5_1.add(emailJTextArea);
            p5.add(p5_1);

            p6 = new JPanel();
            p6.setBorder(BorderFactory.createTitledBorder("Phone number"));
            JPanel p6_1 =new JPanel(new GridLayout(1,1));
            p6_1.setBorder(BorderFactory.createLoweredBevelBorder());//Use createLoweredBevelBorder() method to get embedded border.
            p6_1.setBackground(bgColor);
            phoneJTextArea = new JTextArea("+447654321123",1 ,20);
            p6_1.add(phoneJTextArea);
            p6.add(p6_1);

            p7 = new JPanel();
            p7.setBorder(BorderFactory.createTitledBorder("Booking reference code"));
            JPanel p7_1 =new JPanel(new GridLayout(1,1));
            p7_1.setBorder(BorderFactory.createLoweredBevelBorder());//Use createLoweredBevelBorder() method to get embedded border.
            p7_1.setBackground(bgColor);
            bookingReferencecodeJTextArea = new JTextArea("6EZRd",1,5);
            p7_1.add(bookingReferencecodeJTextArea);
            p7.add(p7_1);

            p8 = new JPanel();
            p8.setBorder(BorderFactory.createEtchedBorder());//Use createEtchedBorder() method to get no title border.
            checkBox1 = new JCheckBox("I have read and agree to the terms and conditions.");
            checkBox2 = new JCheckBox("I confrim that the information provided is correct.");
            p8.add(checkBox1);
            p8.add(checkBox2);

            p9 = new JPanel();
            p9.setBorder(BorderFactory.createLoweredBevelBorder());
            buttonNextstep = new JButton("Next step");
            buttonClear = new JButton("Clear");
            buttonExit = new JButton("Exit");
            /**
             * Let the Layout invalid and set the buttons' postition with setBounds() method.
             */
            p9.setLayout(null);
            buttonNextstep.setBounds(100, 30, 100, 25);
            buttonClear.setBounds(220, 30, 60, 25);
            buttonExit.setBounds(300, 30, 60, 25);
            p9.add(buttonNextstep);
            p9.add(buttonClear);
            p9.add(buttonExit);

        /**
         * Add each JPanel into the main JPanel.
         */
        p.add(p1);
        p.add(p2);
        p.add(p3);
        p.add(p4);
        p.add(p5);
        p.add(p6);
        p.add(p7);
        p.add(p8);
        p.add(p9);
        this.add(p);
        this.setSize(500, 800);// Set the window's size.
        this.setLocation(300, 300);
        this.setResizable(false);// Set the form of the window not to change size.
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        buttonNextstep.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                //The input information is stored and passed through the arrylist
                ArrayList<String> strings = new ArrayList<String>();
                strings.add("Full name : " + firstNameJTextArea.getText() + " " + surnameJTextArea.getText());
                strings.add("Date of birth : " + doBMonthJComboBox.getSelectedItem() + " " + doBYearJComboBox.getSelectedItem());
                strings.add("Programme : " + programmeJComboBox.getSelectedItem() + ", " + programmeYearJComboBox.getSelectedItem());
                strings.add("Email : " + emailJTextArea.getText());
                strings.add("Phone number : " + phoneJTextArea.getText());
                //Use this if else to determine whether JPanel is empty or not.
                if (firstNameJTextArea.getText().equals("") || surnameJTextArea.getText().equals("") || doBMonthJComboBox.getSelectedIndex()==0 || doBYearJComboBox.getSelectedIndex()==0
                || programmeJComboBox.getSelectedIndex()==0 || programmeYearJComboBox.getSelectedIndex()==0 || emailJTextArea.getText().equals("") || phoneJTextArea.getText().equals("")) {
                    JOptionPane.showMessageDialog(null, "Please fill in the missing information", null, JOptionPane.WARNING_MESSAGE);
                    lineBorderRed = BorderFactory.createLineBorder(Color.RED, 2);
                    /**
                     * Belows are many if else to check whether user fill this text or not, and
                     * change the border into lineBorderRed.
                     */
                    if(firstNameJTextArea.getText().equals("")){
                        p2_1.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "First Name"));
                    }
                    else{
                        p2_1.setBorder(BorderFactory.createTitledBorder(lineBorderBlack, "First Name"));
                    }

                    if(surnameJTextArea.getText().equals("")){
                        p2_2.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "surname"));
                    }
                    else{
                        p2_2.setBorder(BorderFactory.createTitledBorder(lineBorderBlack, "surname"));
                    }

                    if(doBMonthJComboBox.getSelectedIndex()==0){
                        p3_1.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "Month"));
                    }
                    else{
                        p3_1.setBorder(BorderFactory.createTitledBorder("Month"));
                    }

                    if(doBYearJComboBox.getSelectedIndex()==0){
                        p3_2.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "Year"));
                    }
                    else{
                        p3_2.setBorder(BorderFactory.createTitledBorder("Year"));
                    }

                    if(programmeJComboBox.getSelectedIndex()==0){
                        p4_1.setBorder(lineBorderRed);
                    }
                    else{
                        p4_1.setBorder(BorderFactory.createLoweredBevelBorder());
                    }

                    if(programmeYearJComboBox.getSelectedIndex()==0){
                        p4_2.setBorder(lineBorderRed);
                    }
                    else{
                        p4_2.setBorder(BorderFactory.createLoweredBevelBorder());
                    }

                    if(emailJTextArea.getText().equals("")){
                        p5_1.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "Email"));
                        emailJTextArea.setSize(100, 10);
                    }
                    else{
                        p5_1.setBorder(BorderFactory.createLoweredBevelBorder());
                    }

                    if(phoneJTextArea.getText().equals("")){
                        p6_1.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "Phone number"));
                    }
                    else{
                        p6_1.setBorder(BorderFactory.createLoweredBevelBorder());
                    }

                    if(bookingReferencecodeJTextArea.getText().equals("")){
                        p7_1.setBorder(BorderFactory.createTitledBorder(lineBorderRed, "Booking reference number"));
                    }
                    else{
                        p7_1.setBorder(BorderFactory.createLoweredBevelBorder());
                    }
                } 
                // If no JPanel is empty, then enter into anothor frame.
                else {
                    if(checkBox1.isSelected() && checkBox2.isSelected()){
                        int a = JOptionPane.showConfirmDialog(null, "Have you checked all the information is correct? You can't change the information once the information is submitted", "Confirm check in?", JOptionPane.YES_NO_OPTION);
                        if (a == JOptionPane.YES_OPTION) {
                            JFrame anothJFrame = new AnotherFrame(strings.get(0), strings.get(1), strings.get(2), strings.get(3), strings.get(4));
                            anothJFrame.setVisible(true);
                            setVisible(false);
                        }
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Please ensure you have checked all the checkbox!", null, JOptionPane.WARNING_MESSAGE);
                    }

                }
            }
        });

        buttonClear.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                // Clear the text in the text box, and make the JCombox's index to 0.
                doBMonthJComboBox.setSelectedIndex(0);
                doBYearJComboBox.setSelectedIndex(0);
                programmeJComboBox.setSelectedIndex(0);
                programmeYearJComboBox.setSelectedIndex(0);
                firstNameJTextArea.setText("");
                surnameJTextArea.setText("");
                emailJTextArea.setText("");
                phoneJTextArea.setText("");
                bookingReferencecodeJTextArea.setText("");
                checkBox1.setSelected(false);
                checkBox2.setSelected(false);
            }
        });

        buttonExit.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                // To exit the programe.
                System.exit(0);
            }
        });
    }
}
